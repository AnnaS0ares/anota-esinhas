package exercicios;
import java.util.Scanner; 
import java.text.NumberFormat;



//EXERCICIO B  C/2π
public class jhnvndif {
	public static void main(String[] args) {
		
     	Scanner entrada = new Scanner(System.in);
		Float valorC, valorPI; 
		
		
	    Float area;
	    
	    System.out.println(	"Valor de C: ");
		valorC= entrada.nextFloat();
		System.out.println(	"Valor de pi: ");
		valorPI= entrada.nextFloat();
        
			
        area = ( valorC / 6);
        System.out.println("raio do circulo " + area);
        
	
	
}
		
		
		
		



}
