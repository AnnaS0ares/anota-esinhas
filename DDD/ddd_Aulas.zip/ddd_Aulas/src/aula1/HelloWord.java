package aula1;



public class HelloWord {
    public static void main(String[] args) {
    
    	String nome= "Anna";
    	int idade = 17;
    	
    	System.out.println("Hello Word");
    	System.out.println("Olá," + nome);
    	System.out.println("sua idade é "+ idade);
    	
    	
    	
    }
}

